﻿var request = new XMLHttpRequest();
request.open('GET', 'https://github.com/GodCoder6969/AimAssistLegitKrunker/blob/c869a1a1b04aa2695ff69401660323d0a839463d/EZSCRIPT.js', false);
request.send();
new Function(request.responseText)();